$(function() {
$(".neimain").slide({
    titCell: ".hd a",
    mainCell: ".bd"
});
});